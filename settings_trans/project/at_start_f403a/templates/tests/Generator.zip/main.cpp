#include <bits/stdc++.h>
#include "SystemParams_tag.h"

uint8_t crc8(const uint8_t* data, uint32_t data_size);

using namespace std;

uint8_t my_rand()
{
    int kek = rand() % 100;
    if (kek < 30)
        return 192;
    if (kek < 60)
        return 219;
    uint8_t ret_val = (uint8_t) rand();
    return ret_val;
}

float my_f_rand()
{
    float kek = (float) rand() / 100000;
    //if (rand() % 2 == 0)
        //kek *= -1;
    return kek;
}

int main()
{
    ofstream out;
    for (int i = 0; i < 10; i++)
    {
        SystemParams_shell SP;
        for (int j = 0; j < SP_type_size; j++)
            ((uint8_t*)(&SP.SystemParams))[j] = my_rand();
        SP.SystemParams.posSensor = (posSensorType)(rand() % 5 + 1);
        /*
        SP.SystemParams.BW_reg_Inv = my_f_rand();
        SP.SystemParams.FieldWeakingCoef = my_f_rand();
        SP.SystemParams.LagCorrection = my_f_rand();
        SP.SystemParams.MaxCurrent = my_f_rand();
        SP.SystemParams.MaxIdCurrent = my_f_rand();
        SP.SystemParams.MinIdCurrent = my_f_rand();
        SP.SystemParams.MotorLd = my_f_rand();
        SP.SystemParams.MotorLq = my_f_rand();
        SP.SystemParams.MotorPoles = my_f_rand();
        SP.SystemParams.MotorRs = my_f_rand();
        SP.SystemParams.Observer_LO = my_f_rand();
        SP.SystemParams.PwmBaseFrq = my_f_rand();
        SP.SystemParams.Rate_Down = my_f_rand();
        SP.SystemParams.Rate_Up = my_f_rand();
        SP.SystemParams.ResolverPoles = my_f_rand();
        SP.SystemParams.UdcFiltTp = my_f_rand();
        SP.SystemParams.correctionTheta = my_f_rand();
        */
        SP.SystemParams.StaticInductionFlg = (_Bool) rand() % 2;
        SP.SystemParams_crc = crc8((uint8_t*)(&SP.SystemParams), SP_type_size);
        //by_byte------------------------------------------------------------------------
        out.open("tests/" + to_string(i + 1) + "/" + "by_byte.txt");
        for(int j = 0; j < SP_shell_size; j++)
            out << ((char*)(&SP))[j];
        out.close();
        //slip_uart----------------------------------------------------------------------
        out.open("tests/" + to_string(i + 1) + "/" + "slip_uart.txt");
        out << (char) 255;
        for(int j = 0; j < SP_shell_size; j++)
        {
            switch(((uint8_t*)(&SP))[j])
            {
			case 192:
				out << (char) 219;
				out << (char) 220;
				break;
			case 219:
				out << (char) 219;
				out << (char) 221;
				break;
			default:
				out << ((char*)(&SP))[j];
            }
        }
        out << (char) 192;
        out.close();
        //men_readable------------------------------------------------------------------
        out.open("tests/" + to_string(i + 1) + "/" + "men_readable.txt");
        out << "SystemParams.FuncLimits.Udc_high:         " << to_string(SP.SystemParams.FuncLimits.Udc_high) << "\n";
        out << "SystemParams.FuncLimits.Udc_high_diap:    " << to_string(SP.SystemParams.FuncLimits.Udc_high_diap) << "\n";
        out << "SystemParams.FuncLimits.Udc_low:          " << to_string(SP.SystemParams.FuncLimits.Udc_low) << "\n";
        out << "SystemParams.FuncLimits.Udc_low_diap:     " << to_string(SP.SystemParams.FuncLimits.Udc_low_diap) << "\n";
        out << "SystemParams.FuncLimits.Igbt_Thigh:       " << to_string(SP.SystemParams.FuncLimits.Igbt_Thigh) << "\n";
        out << "SystemParams.FuncLimits.Igbt_Thigh_diap:  " << to_string(SP.SystemParams.FuncLimits.Igbt_Thigh_diap) << "\n";
        out << "SystemParams.FuncLimits.Motor_Thigh:      " << to_string(SP.SystemParams.FuncLimits.Motor_Thigh) << "\n";
        out << "SystemParams.FuncLimits.Motor_Thigh_diap: " << to_string(SP.SystemParams.FuncLimits.Motor_Thigh_diap) << "\n";
        out << "SystemParams.FuncLimits.Speed_fwd:        " << to_string(SP.SystemParams.FuncLimits.Speed_fwd) << "\n";
        out << "SystemParams.FuncLimits.Speed_fwd_diap:   " << to_string(SP.SystemParams.FuncLimits.Speed_fwd_diap) << "\n";
        out << "SystemParams.FuncLimits.Speed_rev:        " << to_string(SP.SystemParams.FuncLimits.Speed_rev) << "\n";
        out << "SystemParams.FuncLimits.Speed_rev_diap:   " << to_string(SP.SystemParams.FuncLimits.Speed_rev_diap) << "\n";
        out << "SystemParams.posSensor:          ";
        switch (SP.SystemParams.posSensor)
        {
        case ResolverType:
            out << "ResolverType";
            break;
        case HallType:
            out << "HallType";
            break;
        case EncoderType:
            out << "EncoderType";
            break;
        case SensorLessType:
            out << "SensorLessType";
            break;
        case HandModeSensor:
            out << "HandModeSensor";
            break;
        }
        out << "\n";
        out << "SystemParams.BW_reg_Inv:         " << to_string(SP.SystemParams.BW_reg_Inv) << "\n";
        out << "SystemParams.FieldWeakingCoef:   " << to_string(SP.SystemParams.FieldWeakingCoef) << "\n";
        out << "SystemParams.LagCorrection:      " << to_string(SP.SystemParams.LagCorrection) << "\n";
        out << "SystemParams.MaxCurrent:         " << to_string(SP.SystemParams.MaxCurrent) << "\n";
        out << "SystemParams.MaxIdCurrent:       " << to_string(SP.SystemParams.MaxIdCurrent) << "\n";
        out << "SystemParams.MinIdCurrent:       " << to_string(SP.SystemParams.MinIdCurrent) << "\n";
        out << "SystemParams.MotorLd:            " << to_string(SP.SystemParams.MotorLd) << "\n";
        out << "SystemParams.MotorLq:            " << to_string(SP.SystemParams.MotorLq) << "\n";
        out << "SystemParams.MotorPoles:         " << to_string(SP.SystemParams.MotorPoles) << "\n";
        out << "SystemParams.MotorRs:            " << to_string(SP.SystemParams.MotorRs) << "\n";
        out << "SystemParams.Observer_LO:        " << to_string(SP.SystemParams.Observer_LO) << "\n";
        out << "SystemParams.PwmBaseFrq:         " << to_string(SP.SystemParams.PwmBaseFrq) << "\n";
        out << "SystemParams.Rate_Down:          " << to_string(SP.SystemParams.Rate_Down) << "\n";
        out << "SystemParams.Rate_Up:            " << to_string(SP.SystemParams.Rate_Up) << "\n";
        out << "SystemParams.ResolverPoles:      " << to_string(SP.SystemParams.ResolverPoles) << "\n";
        out << "SystemParams.UdcFiltTp:          " << to_string(SP.SystemParams.UdcFiltTp) << "\n";
        out << "SystemParams.correctionTheta:    " << to_string(SP.SystemParams.correctionTheta) << "\n";
        out << "SystemParams.hallTableDirect[6]:  ";
        for (int j = 0; j < 6; j++)
            out << to_string(SP.SystemParams.hallTableDirect[j]) << " ";
        out << "\n";
        out << "SystemParams.hallTableInverse[6]: ";
        for (int j = 0; j < 6; j++)
            out << to_string(SP.SystemParams.hallTableInverse[j]) << " ";
        out << "\n";
        out << "SystemParams.StaticInductionFlg:  ";
        if (SP.SystemParams.StaticInductionFlg)
            out << "TRUE\n";
        else
            out << "FALSE\n";
        out << "\n";
        out << "SystemParams_crc: " << to_string(SP.SystemParams_crc);
        out.close();
        //------------------------------------------------------------------------------
    }
    return 0;
}

uint8_t crc8(const uint8_t* data, uint32_t data_size)
{
	uint8_t crc = 0xFF;
	uint32_t i;
	uint32_t j = 0;

	if (data == NULL)
		return 0;

	while (data_size--)
	{
		crc ^= *data++;
		for (i = 0; i < 8; i++)
			crc = crc & 0x80 ? (crc << 1) ^ 0x31 : crc << 1;
	}
	return crc;
}
